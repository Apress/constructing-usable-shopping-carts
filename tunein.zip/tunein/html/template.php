<?php
  require_once "../includes/top.inc";
?>
<body>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr> <!--Masthead table row-->
      <td bgcolor="#CCCCCC" width="150" class="tunein">
        <h1>Tune<em class="in">In</em>!</h1>
      </td>
      <td bgcolor="#CCCCCC" align="right">
<!-- SEARCH -->
<?php
  require_once "../includes/search.inc";
?>
      </td>
    </tr>
  </table>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td valign="top" align="left" width="150" bgcolor="#CCCCCC">
<!-- NAVIGATION -->
<?php
  require_once "../includes/navbar.inc";
?>
      </td>
      <td valign="top">
<!-- CONTENT AREA -->
<h2>Jake Mandell</h2>
<p>Lorem ipsum dolor sit amet <a href="blerg.html">consectateur nonummy</a> lorenzino. Interdum volgus videt, est ubi
peccat. Si veteres ita miratur laudatque poetas, <a href="#">ut nihil anteferat</a>, nihil illis comparet,
errat. Si quaedam nimis antique, si peraque dure dicere credit eos, ignave multa fatetur,
et sapit et mecum facit et Iova iudicat aequo.</p>

<p>Lorem ipsum dolor sit amet consectateur nonummy lorenzino. Interdum volgus videt, est ubi
peccat. Si veteres ita miratur laudatque poetas, ut nihil anteferat, nihil illis comparet,
errat. Si quaedam nimis antique, si peraque dure dicere credit eos, ignave multa fatetur,
et sapit et mecum facit et Iova iudicat aequo.</p>

<p>Lorem ipsum dolor sit amet consectateur nonummy lorenzino. Interdum volgus videt, est ubi
peccat. Si veteres ita miratur laudatque poetas, ut nihil anteferat, nihil illis comparet,
errat. Si quaedam nimis antique, si peraque dure dicere credit eos, ignave multa fatetur,
et sapit et mecum facit et Iova iudicat aequo.</p>
      </td>
      <td valign="top" align="right" width="200">
<?php
  require_once "../includes/short_cart.inc";
?>
      </td>
    </tr>
  </table>
</body>
</html>
