<?php
  require_once "../includes/top.inc";
?>
<body>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr> <!--Masthead table row-->
      <td bgcolor="#CCCCCC" width="150" class="tunein">
        <h1>Tune<em class="in">In</em>!</h1>
      </td>
      <td bgcolor="#CCCCCC" align="right">
<!-- SEARCH -->
<?php
  require_once "../includes/search.inc";
?>
      </td>
    </tr>
  </table>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td valign="top" align="left" width="150" bgcolor="#CCCCCC">
<!-- NAVIGATION -->
<?php
  require_once "../includes/navbar.inc";
?>
      </td>
      <td valign="top">
<!-- CONTENT AREA -->
<h2>Help / About The Site</h2>
<h3>Music Section</h3>
<p>Stuff about using the Music Section... Stuff about using the Music Section...
Stuff about using the Music Section... Stuff about using the Music Section...
Stuff about using the Music Section... Stuff about using the Music Section...
Stuff about using the Music Section... Stuff about using the Music Section...</p>
<h3>Events Section</h3>
<p>Stuff about the Events Section... Stuff about the Events Section... Stuff about the Events Section...
Stuff about the Events Section... Stuff about the Events Section... Stuff about the Events Section...
Stuff about the Events Section... Stuff about the Events Section... Stuff about the Events Section...
Stuff about the Events Section... Stuff about the Events Section... Stuff about the Events Section...</p>
<h3>News Section</h3>
<p>Stuff about the News Section... Stuff about the News Section... Stuff about the News Section...
Stuff about the News Section... Stuff about the News Section... Stuff about the News Section...
Stuff about the News Section... Stuff about the News Section... Stuff about the News Section...
Stuff about the News Section... Stuff about the News Section... Stuff about the News Section...</p>
<h3>Shopping Cart &amp; Checkout</h3>
<p>Stuff about usng the cart... Stuff about usng the cart... Stuff about usng the cart...
Stuff about usng the cart... Stuff about usng the cart... Stuff about usng the cart...
Stuff about usng the cart... Stuff about usng the cart... Stuff about usng the cart...
Stuff about usng the cart... Stuff about usng the cart... Stuff about usng the cart...</p>
<h3>Artist/Music Search</h3>
<p>Stuff about using the Search utility... Stuff about using the Search utility... Stuff about using the
Search utility... Stuff about using the Search utility... Stuff about using the Search utility...
Stuff about using the Search utility... Stuff about using the Search utility...
Stuff about using the Search utility... Stuff about using the Search utility... Stuff about using the
Search utility... Stuff about using the Search utility... </p>
      </td>
      <td valign="top" align="right" width="200">
<?php
  require_once "../includes/short_cart.inc";
?>
      </td>
    </tr>
  </table>
</body>
</html>
